1. At first install and activat the plugin 
++++++++++++++++++++++++++++++++++++++++++++++++
2. make a menu and save it
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
3.Insert your movie list in the add new button
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


